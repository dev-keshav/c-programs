#include <stdio.h>

int main()
{
    int i,m,n,temp;
    int sum=0;
    printf("Enter the power: ");
    scanf("%d", &n);
    
    printf("\nEnter the last number: ");
    scanf("%d", &m);
    for(i=1; i<=m; i++){
        temp=pow(i,n);
        sum=sum+temp;
    }
    printf("\nThe sum is: %d", sum);

    return 0;
}
