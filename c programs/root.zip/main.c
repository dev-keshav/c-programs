/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
     float a,b,c,dis,root1,root2;
    printf("Enter the three value: ");
    scanf("%f %f %f", &a, &b,&c);
    dis= b*b-4*a*c;
    printf("The value of Discriminant: %f",dis);
    
    if(dis>0){
        root1=(-b+sqrt(dis))/(2*a);
        root2=(-b-sqrt(dis))/(2*a);
        printf("The value of 1st root: %f", root1);
        printf("The value of 2nd root: %f", root2);
    }
    else if(dis==0){
        root1=root2=b*b-4*a*c;
        printf("The value of 1st and 2nd roots are: %f", root1, root2);
    }

    return 0;
}
