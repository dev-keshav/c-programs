#include <stdio.h>

int main()
{
    int i,j,n,temp,min;
    printf("Enter the size of an array: ");
    scanf("%d", &n);
    
    printf("Enter the %d elements for the array\n", n);
    
    int arr[n];
    for(i=0; i<n; i++){
        scanf("%d", &arr[i]);
    }
    
    printf("Sorted array\n");
    for(i=0; i<n-1; i++){
        min=i;
        for(j=i+1; j<n; j++){
            if(arr[j]<arr[min]){
                min=j;
            }
        }
        temp=arr[min];
            arr[min]=arr[i];
            arr[i]=temp;
        }
        for(i=0; i<n; i++){
        printf("%d", arr[i]);
        printf("\n");
    }

    return 0;
}

