
#include <stdio.h>

int main()
{
    printf("Enter a number: ");
    int a;
    scanf("%d",&a);
    if(a%2==0)
    {
        printf("The number you have entered is even i.e, %d\n", a);
    }
    else
    {
        printf("The number you have entered is odd i.e, %d\n", a);
    }

    return 0;
}
