/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int no;
    
    printf("Enter your number\n");
    scanf("%d", &no);
    
    
    if(no==1){
        printf("your number is 1\n");
        
    }
    else if(no==2){
        printf("your number is 2\n");
        
    }
    else if(no==3){
        printf("your number is 3\n");
        
    }
    else if(no>=4){
        printf("your no is greater than 3\n");
        
    }
    else if(no<=0){
        printf("your number is smaller than 1\n");
        
    }
    else{
        printf("invalid");
    }

    return 0;
}
