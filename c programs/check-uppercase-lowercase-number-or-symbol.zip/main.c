#include <stdio.h>

int main()
{
    printf("Enter a character, digit or any symbol: \n");
    char ch;
    
    scanf("%c", &ch);
    if(ch>=65 && ch<=90)
    {
        printf("This is a upper case character.\n");
    }
    else if(ch>=97 && ch<=122)
    {
        printf("This is a lower case character.\n");
    }
    else if(ch>=48 && ch<=57)
    {
        printf("This is number.\n");
    }
    else
    {
        printf("This is a special character or symbol.\n");
    }

    return 0;
}

