#include <stdio.h>

int main()
{
    int size1, size2, a[7][7], b[7][7], i,j;
    int add[7][7], sub[7][7], mult[7][7], divd[7][7], modu[7][7];
    printf("Enter the no. of row for the array:\n");
    scanf("%d", &size1);
    printf("Enter the no. of column for the array:\n");
    scanf("%d", &size2);
    
    printf("Enter the elements for 1st array:\n");
    for(i=0; i<size1; i++)
    {
        for(j=0; j<size2; j++)
        {
            scanf("%d", &a[i][j]);
        }
        printf("\n");
    }
    
    printf("Enter the elements for 2st array:\n");
    for(i=0; i<size1; i++)
    {
        for(j=0; j<size2; j++)
        {
            scanf("%d", &b[i][j]);
        }
        printf("\n");
    }
    for(i=0; i<size1; i++)
    {
        for(j=0; j<size2; j++)
        {
    add[i][j]=a[i][j]+b[i][j];
    sub[i][j]=a[i][j]-b[i][j];
    mult[i][j]=a[i][j]*b[i][j];
    divd[i][j]=a[i][j]/b[i][j];
    modu[i][j]=a[i][j]%b[i][j];
        }
    }
    printf("\nSum\t Sub\t Mult\t Div\t mod\n");
    for(i=0; i<size1; i++)
    {
        for(j=0; j<size2; j++)
        {
            printf("%d\t", add[i][j]);
            printf("%d\t", sub[i][j]);
            printf("%d\t", mult[i][j]);
            printf("%d\t", divd[i][j]);
            printf("%d\n", modu[i][j]);
        }
        printf("\n");
    }


    return 0;
}
