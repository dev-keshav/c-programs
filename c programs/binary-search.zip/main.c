#include <stdio.h>
int binarySearch(int arr[], int x, int l, int r)
{
    if (r >= l)
    {
        int mid = (l + r) / 2;

        if (arr[mid] == x)
            return mid;

        else if (arr[mid] > x)
            return binarySearch(arr, x, l, mid - 1);

        else
            return binarySearch(arr, x, mid + 1, r);
    }
    return -1;
}

int main(void)
{
    int arr[] = {12, 34, 45, 62, 65, 76, 86, 92};
    int x = 86;
    int n = sizeof(arr) / sizeof(arr[0]);
    int result = binarySearch(arr, x, 0, n - 1);
    if (result == -1)
    {
        printf("Element %d is not found in the Array", result);
    }
    else
    {
        printf("Element %d is found in the Array at index %d", x, result);
    }

    return 0;
}