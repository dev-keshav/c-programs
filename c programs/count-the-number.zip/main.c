#include <stdio.h>

int main()
{
    int a;
    printf("Enter the number: ");
    scanf("%d", &a);
    
    int count=0;
    while(a>0){
        a=a/10;
        count++;
    }
    printf("%d",count);

    return 0;
}
