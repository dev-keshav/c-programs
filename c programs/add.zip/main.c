
#include <stdio.h>
#include <math.h>
void main()
{
    // int a,b,c;
    // a=6;
    // b=7;
    // c=a*b;
    // printf("This is the answer: %d\n", c);
    printf("The value of 3^2 is %f\n", pow(3,2));

    return 0;
}
