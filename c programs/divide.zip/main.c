
#include <stdio.h>
#include <math.h>
int main()
{
    // int k=3.0/9;
    printf("the value: %f", 3.0/9);

    return 0;
}
