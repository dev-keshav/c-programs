#include <stdio.h>

int main()
{
    int s, a[8], b[8];
    int i, sum[8], sub[8], mult[8], modu[8];
    float divd[8];
    printf("Enter the size of array\n");
    scanf("%d", &s);
    printf("Enter the elements of 1st array\n");
    for(i=0; i<s; i++)
    {
        scanf("%d", &a[i]);
    }
    
    printf("Enter the elements of 2nd array\n");
    for(i=0; i<s; i++)
    {
        scanf("%d", &b[i]);
    }
    
    for(i=0; i<s; i++)
    {
    sum[i]=a[i]+b[i];
    sub[i]=a[i]-b[i];
    mult[i]=a[i]*b[i];
    divd[i]=(float)a[i]/b[i];
    modu[i]=a[i]%b[i];
    }
    
    printf("\n Sum\t Sub\t Mult\t Div\t Mod\n");
    for(i=0; i<s; i++)
    {
        printf("%d\t", sum[i]);
        printf("%d\t", sub[i]);
        printf("%d\t", mult[i]);
        printf("%0.2f\t", divd[i]);
        printf("%d\n", modu[i]);
    }

    return 0;
}
