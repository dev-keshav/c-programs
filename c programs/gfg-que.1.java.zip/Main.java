public class Main
{
    
    public static boolean checkElementHelper(int[] arr, int len, int x, int k) {
			boolean flag=false;
			int i;
			int j=0;
			for(i=0; i<len; i=i+k) {
				for(j=i; j<i+k; j++) {
					if(j<len && arr[j]==x) {
						break;
					}
					else if(j==i+k || j>len) {
						return false;
					}
				}
			}
			if(j<len) {
				return true;
			}
			return flag;
		}
		
    
	public static void main(String[] args) {
		int arr[] = new int[] {3,5,2,4,9,3,1,7,3,11,12,3};
	        int x =3 ;
	        int k = 3;
	        int l = arr.length;
	       
	        if(checkElementHelper(arr,l,x,k)) {
	        	System.out.println("Yes");
	        }
	        else {
	        	System.out.println("No");
	        }
	}
}
