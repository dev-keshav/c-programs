#include <stdio.h>

int main()
{
    
    int Size, i, a[10], b[10];
    int add[10], sub[10], mult[10], modu[10];
    
    
    printf("Enter the Size of the Array\n");
 scanf("%d", &Size);
 
 printf("Enter the First Array Elements\n");
 for(i = 0; i < Size; i++)
  {
      scanf("%d", &a[i]);
  }
  printf("\nPlease Enter the Second Array Elements\n");
 for(i = 0; i < Size; i ++)
  {
      scanf("%d", &b[i]);
  }
  for(i = 0; i < Size; i ++)
  {
      add[i]= a[i] + b[i];
      sub[i]= a[i] - b[i];
      mult[i]= a[i] * b[i];
      modu[i] = a[i] % b[i];
  }
  printf("\n Add\t Sub\t Multi\t Mod");
  for(i = 0; i < Size; i++)
  {
      printf("\n%d \t ", add[i]);
      printf("%d \t ", sub[i]);
      printf("%d \t ", mult[i]);
      printf("%d \t ", modu[i]);
  }

    return 0;
}

