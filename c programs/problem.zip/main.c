/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a,b; 
    float c,d;
    
    
	printf("Enter first number\n");
	scanf("%d", &a);
	printf("Enter second number\n");
	scanf("%d", &b );
	
// 	printf("%d, %d", a, b);
	c=a*b;
    d=a/b;
    
    printf("The multiplication is %f\nand the division is  %f", c, d);

    return 0;
}
