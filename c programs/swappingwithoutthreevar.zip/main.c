
#include <stdio.h>

int main()
{
    printf("Enter two numbers:\n");
    int a,b;
    scanf("%d %d", &a, &b);
    printf("a=%d\n",a);
    printf("b=%d\n",b);
    a=a+b;
    b=a-b;
    a=a-b;
    printf("\n");
    printf("After swapping of two numbers:\n");
    printf("a=%d\nb=%d\n", a,b);

    return 0;
}
