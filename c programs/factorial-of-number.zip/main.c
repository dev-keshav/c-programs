#include <stdio.h>

int main()
{
    printf("Enter a number to find factorial\n");
    int a,fac;
    scanf("%d", &a);
    int i=1;
    fac=1;
    while(i<=a){
        fac=fac*i;
        i++;
    }
    printf("The factorial of %d is %d", a, fac);
    return 0;
}

