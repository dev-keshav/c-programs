#include <stdio.h>
typedef struct student{
    int rollno;
    char name[50];
    struct subject{
      int scode;
      char subName[60];
      int marks;
    }sub[5];
    int total;
    float per;
}student;

void create(){}
void display(){}
void append(){}

int main(){
    int ch;
    do{
        printf("\n1.CREATE");
        printf("\n2.DISPLAY");
        printf("\n3.APPEND");
        printf("\n0.EXIT");
        
        printf("\nEnter your choice: ");
        scanf("%d",&ch);
        
        switch(ch){
            case 1:
            create();
            break;
            
            case 2:
            display();
            break;
            
            case 3:
            append();
            break;
            
        }
    }while(ch!=0);
    
    return 0;
}

