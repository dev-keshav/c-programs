/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    
	float a,b,c,d;
	
	printf("Enter first number\n");
	scanf("%f", &a);
	
	printf("Enter second number\n");
	scanf("%f", &b);
	
	c=a*b;
	d=a/b;
	
	printf("Multiplication is %f\n Division is %f\n", c, d);
	
	return 0;

}
