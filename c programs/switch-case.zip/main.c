/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int x;
    printf("Enter Week in number\n");
    scanf("%d", &x);
    
    switch(x){
        case 1:
        printf("Monday\n");
        break;
        
        case 2:
        printf("Tuesday\n");
        break;
        
        case 3:
        printf("Wednesday\n");
        break;
        
        case 4:
        printf("Thrusday\n");
        break;
        
        case 5:
        printf("Friday\n");
        break;
        
        case 6:
        printf("Saturday\n");
        break;
        
        case 7:
        printf("Sunday\n");
        break;
        
        default:
        printf("Invalid\n");

    }

    return 0;
}
