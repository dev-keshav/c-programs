
sum = 0
for n in range(1, 11):
    sum = sum + n

print("Sum of first 10 numbers is:", sum)