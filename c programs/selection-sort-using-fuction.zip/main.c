#include <stdio.h>

void swap(int *x, int *y){
    int temp;
    temp=*x;
    *x=*y;
    *y=temp;
}

void selectionSort(int arr[], int n)
{
    int min;
    
    for(int i=0; i<n-1; i++){
        min=i;
        for(int j=i+1; j<n; j++){
            if(arr[j]<arr[min]){
                min=j;
            }
            
        }
        swap(&arr[min], &arr[i]);
    }
}

int printArray(int arr[], int size){
    for(int i=0; i<size; i++){
        printf("%d", arr[i]);
        printf("\n");
    }
}

int main(){
    int arr[] = {76, 56, 23, 67, 90, 522, 64,89,21,56};
    int n = sizeof(arr)/sizeof(arr[0]);
    selectionSort(arr, n);
    printf("Sorted array: \n");
    printArray(arr, n);
    return 0;
}    



