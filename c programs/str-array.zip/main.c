#include <stdio.h>

struct students{
    char name[67];
    int marks;
    
};
void main(){
    struct students s1, s2, s3;
    int a;
    printf("Enter the name and marks of the student 1");
    scanf("%s %d", s1.name,&s1.marks);
    scanf("%c",&a);
    
    printf("Enter the name and marks of the student 2");
    scanf("%s %d", s2.name,&s2.marks);
    scanf("%c",&a);
    
    printf("Enter the name and marks of the student 3");
    scanf("%s %d", s3.name,&s3.marks);
    scanf("%c",&a);
    
    printf("Student's detail:\n");
    
    printf("%s %d\n", s1.name,s1.marks);
    printf("%s %d\n", s2.name,s2.marks);
    printf("%s %d\n", s3.name,s3.marks);
    
}