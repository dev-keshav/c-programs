/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    printf("Enter two numbers\n");
    int a,b,c;
    scanf("%d %d", &a, &b);
    printf("a=%d\nb=%d\n", a,b);
    c=a;
    a=b;
    b=c;
    printf("After swapping of numbers are:\n a=%d\n b=%d\n",a,b);


    return 0;
}
