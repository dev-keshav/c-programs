/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    // printf("Hello World");
    
    int a =4;
    int b =7;
    printf("The value of a+b is: %d", a+b);
    

    return 0;
}
