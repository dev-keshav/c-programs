#include <stdio.h>

int main()
{
    int a, b, c, d;
    printf("Enter four numbers:\n");
    scanf("%d %d %d %d", &a, &b, &c, &d);
    
    printf("\nMaximum of the four number is: ");
    
    if(a>b){
        if(a>c){
            if(a>d){
                printf("%d", a);
            }
            else{
                printf("%d", d);
            }
        }
    }
    else if(b>c){
        if(b>d){
            if(b>a){
                printf("%d", b);
            }
            else{
                printf("%d", a);
            }
        }
    }
    else if(c>d){
        if(c>a){
            if(c>b){
                printf("%d", c);
            }
            else{
                printf("%d", b);
            }
        }
    }
    else{
        printf("%d", d);
    }

    return 0;
}
